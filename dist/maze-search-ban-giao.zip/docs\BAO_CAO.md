<!-- COVER -->
**[TÊN TRƯỜNG ĐẠI HỌC / CAO ĐẲNG]**

**[TÊN KHOA / BỘ MÔN]**

---

**BÁO CÁO ĐỒ ÁN HỌC PHẦN**

**LẬP TRÌNH HƯỚNG ĐỐI TƯỢNG**

**ĐỀ TÀI**

**ỨNG DỤNG TÌM ĐƯỜNG TRONG MÊ CUNG**

**BẰNG THUẬT TOÁN BFS, DFS VÀ A***

Giảng viên hướng dẫn: [Họ và tên giảng viên]

Lớp học phần: [Mã lớp] — Nhóm thực hiện: [Số nhóm]

| STT | Họ và tên sinh viên | Mã số sinh viên |
|---|---|---|
| 1 | [Họ và tên sinh viên 1] | [MSSV 1] |
| 2 | [Họ và tên sinh viên 2] | [MSSV 2] |
| 3 | [Họ và tên sinh viên 3] | [MSSV 3] |

**[Địa phương], tháng 11 năm 2026**
<!-- /COVER -->

# LỜI MỞ ĐẦU

Tìm đường là một bài toán cơ bản trong tin học, xuất hiện trong trò chơi, hệ thống dẫn đường và mô phỏng. Mê cung dạng lưới là môi trường phù hợp để quan sát bài toán này vì trạng thái, vật cản và kết quả đều có thể biểu diễn trực quan. Trên cùng một mê cung, cách tổ chức dữ liệu chờ xử lý sẽ tạo ra những thứ tự tìm kiếm khác nhau, giúp người học hiểu rõ hơn về thuật toán và cấu trúc dữ liệu.

Đồ án “Ứng dụng tìm đường trong mê cung bằng thuật toán BFS, DFS và A*” vận dụng kiến thức Lập trình hướng đối tượng để xây dựng một ứng dụng desktop hoàn chỉnh. Người sử dụng có thể tạo lưới, chỉnh sửa vật cản, chọn vị trí bắt đầu và đích, chạy thuật toán và theo dõi hoạt ảnh. Bên cạnh tính đúng của đường đi, đồ án chú trọng việc phân chia trách nhiệm giữa các lớp và khả năng giữ giao diện phản hồi khi tìm kiếm.

Báo cáo trình bày yêu cầu, cơ sở lý thuyết, thiết kế, triển khai, kiểm thử và hướng phát triển. Các mô tả kỹ thuật được đối chiếu với mã nguồn bàn giao. Kết quả kiểm thử lấy từ log thực tế; phần chưa kiểm chứng được nêu riêng. Thông tin cá nhân và phân công cần được nhóm xác nhận trước khi nộp chính thức.

<!-- TOC_TITLE -->
# MỤC LỤC

<!-- TOC -->

- Chương 1. Tổng quan và phân tích yêu cầu
- Chương 2. Cơ sở lý thuyết và thuật toán
- Chương 3. Phân tích và thiết kế hướng đối tượng
- Chương 4. Xây dựng và sử dụng ứng dụng
- Chương 5. Kiểm thử và đánh giá kết quả
- Chương 6. Tổ chức thực hiện và phân công nhóm
- Chương 7. Kết luận và hướng phát triển
- Tài liệu tham khảo
- Phụ lục A. Cài đặt và chạy chương trình
- Phụ lục B. Nội dung chuẩn bị bảo vệ

# DANH MỤC TỪ VIẾT TẮT

| Ký hiệu | Tên đầy đủ | Ý nghĩa |
|---|---|---|
| OOP | Object-Oriented Programming | Lập trình hướng đối tượng |
| BFS | Breadth-First Search | Tìm kiếm theo chiều rộng |
| DFS | Depth-First Search | Tìm kiếm theo chiều sâu |
| A* | A-Star Search | Tìm kiếm sử dụng chi phí và heuristic |
| GUI | Graphical User Interface | Giao diện đồ họa |
| EDT | Event Dispatch Thread | Luồng xử lý sự kiện của Swing |
| JDK | Java Development Kit | Bộ công cụ phát triển Java |
| JAR | Java Archive | Tệp đóng gói chương trình Java |
| UML | Unified Modeling Language | Ngôn ngữ mô hình hóa thống nhất |
| S / G | Start / Goal | Ô bắt đầu / ô đích |

# CHƯƠNG 1. TỔNG QUAN VÀ PHÂN TÍCH YÊU CẦU

## 1.1. Lý do chọn đề tài

Thuật toán tìm đường thường được giảng dạy qua mô tả hoặc ví dụ trên giấy. Giao diện trực quan cho phép người học thay đổi mê cung và quan sát sự khác biệt giữa các phương pháp. Bài toán có phạm vi vừa đủ cho nhóm ba sinh viên: dữ liệu rõ ràng, có thể kiểm thử độc lập và có nhiều vị trí thể hiện kiến thức hướng đối tượng.

Triển khai ba thuật toán trên cùng một hợp đồng tìm kiếm tạo điều kiện áp dụng trừu tượng và đa hình. Mô hình lưới tạo ví dụ cho đóng gói dữ liệu; lớp trừu tượng chia sẻ truy vết tạo ví dụ cho kế thừa. Phần giao diện và xử lý nền kết nối các kiến thức trên với một sản phẩm sử dụng được.

## 1.2. Mục tiêu

Đồ án có ba mục tiêu: tìm đường đúng với mô hình bốn hướng và chi phí mỗi bước bằng 1; tổ chức mã nguồn hướng đối tượng, tách thuật toán khỏi giao diện; cung cấp thao tác chỉnh sửa, lưu trữ và quan sát kết quả thuận tiện cho việc học và trình diễn.

Sản phẩm gồm mã nguồn, cấu hình Maven, bộ kiểm thử JUnit 5, JAR, script chạy, mê cung mẫu và tài liệu. Java 17 là mức ngôn ngữ và bytecode trong pom.xml. Phiên kiểm chứng sử dụng JDK 21 với tùy chọn biên dịch release 17.

## 1.3. Phạm vi và đối tượng sử dụng

Ứng dụng dành cho sinh viên, giảng viên hoặc người muốn quan sát các thuật toán tìm đường. Chương trình hoạt động cục bộ trên máy có Java và môi trường đồ họa; không yêu cầu tài khoản, cơ sở dữ liệu hoặc máy chủ.

Mê cung là lưới chữ nhật từ 5×5 đến 100×100. Chỉ di chuyển giữa các ô kề cạnh, không có đường chéo, trọng số thay đổi hoặc vật cản chuyển động. Chương trình không đặt mục tiêu xử lý bản đồ giao thông thực tế.

## 1.4. Yêu cầu chức năng

| Mã | Chức năng | Điều kiện chấp nhận |
|---|---|---|
| CN01 | Tạo lưới | Số hàng và cột trong khoảng 5–100 |
| CN02 | Chỉnh tường | Nhấn/kéo chuột để thêm hoặc xóa; không chặn S/G |
| CN03 | Chọn S và G | Chọn ô trống; công cụ chuột yêu cầu hai điểm khác nhau |
| CN04 | Chọn thuật toán | BFS, DFS và A* sử dụng cùng mô hình mê cung |
| CN05 | Tìm và hiển thị | Tô ô mở rộng, đường kết quả; báo khi không có đường |
| CN06 | Hoạt ảnh | Đổi tốc độ trong lúc phát, hỗ trợ hủy |
| CN07 | Đặt lại kết quả | Hủy tác vụ, xóa màu kết quả, giữ tường và S/G |
| CN08 | Xóa mê cung | Hủy tác vụ, xóa tường và kết quả, giữ S/G |
| CN09 | Lưu và mở | Văn bản UTF-8; kiểm tra trước khi thay mô hình |
| CN10 | Thống kê | Số bước, số ô mở rộng, thời gian thuật toán |

## 1.5. Yêu cầu phi chức năng và quy tắc

| Nhóm yêu cầu | Cách đáp ứng |
|---|---|
| Dễ sử dụng | Tiếng Việt, chú giải màu, thanh trạng thái |
| Tính đúng | Kiểm tra đường hợp lệ và đối chiếu BFS/A* |
| Khả năng phản hồi | SwingWorker cho tìm kiếm, Timer cho hoạt ảnh |
| Bảo vệ dữ liệu | Mở lỗi giữ mê cung; hỏi trước khi lưu đè |
| Dễ bảo trì | Package theo trách nhiệm, mỗi lớp chính một tệp |
| Tái lập | Khởi tạo dữ liệu mỗi lần chạy, test ngẫu nhiên có seed |

Tọa độ phải trong lưới; S/G không nằm trên tường; bước đi chỉ lên, phải, xuống, trái. Độ dài là số bước, không phải số ô. Tầng mô hình và thuật toán hỗ trợ S trùng G để xử lý trường hợp biên; công cụ chuột yêu cầu hai vị trí khác nhau.

## 1.6. Tình huống sử dụng chính

| Tình huống | Luồng thực hiện | Kết quả mong đợi |
|---|---|---|
| Tìm đường | Tạo/mở → chọn thuật toán → Chạy | Đường kết quả hoặc thông báo bế tắc |
| Chỉnh sửa | Chọn công cụ → nhấn/kéo lưới | Cập nhật ô, xóa kết quả cũ |
| Hủy | Nhấn Hủy khi tìm hoặc hoạt ảnh | Dừng tác vụ, có thể chạy lại |
| Mở tệp lỗi | Chọn tệp không hợp lệ | Báo lỗi, giữ mê cung đang dùng |
| Lưu đè | Chọn tệp đã tồn tại | Chỉ ghi sau khi xác nhận |

# CHƯƠNG 2. CƠ SỞ LÝ THUYẾT VÀ THUẬT TOÁN

## 2.1. Mô hình hóa mê cung thành đồ thị

Mê cung tương ứng một đồ thị không trọng số. Mỗi ô trống là một đỉnh; hai đỉnh có cạnh nối nếu kề nhau theo bốn hướng. Tường không được đưa vào tập đỉnh di chuyển. Bài toán là tìm một dãy ô liên tiếp từ S đến G, hoặc xác định không có đường.

Với ô (r, c), các vị trí ứng viên theo thứ tự là (r−1, c), (r, c+1), (r+1, c), (r, c−1). Maze.neighbors lọc vị trí ngoài biên và ô tường. Ba thuật toán cùng dùng phương thức này nên thống nhất quy tắc di chuyển.

Đường đi p₀, p₁, …, pₖ có p₀ = S và pₖ = G. Do mỗi cạnh tốn 1, độ dài bằng k. Đường có 9 ô dài 8 bước; S = G tạo đường một ô dài 0 bước. Đây là quy ước của cả mô hình kết quả và kiểm thử.

## 2.2. Thuật toán BFS

BFS mở rộng các đỉnh theo từng lớp khoảng cách từ S. Chương trình dùng ArrayDeque qua kiểu Queue để tạo hàng đợi FIFO. S được thêm và đánh dấu trước khi vòng lặp bắt đầu. Mỗi lượt lấy một ô đầu hàng đợi, ghi vào danh sách mở rộng; nếu là G thì truy vết, ngược lại thêm hàng xóm chưa phát hiện.

visited được cập nhật ngay khi đưa ô vào hàng đợi, parent ghi bằng ô đang mở rộng. Cách này tránh đưa một ô vào nhiều lần và tạo cây truy vết không có chu trình. Vì mọi cạnh cùng chi phí, lần phát hiện đầu tiên của BFS ứng với khoảng cách nhỏ nhất tới ô đó.

BFS bảo đảm số bước ít nhất trong phạm vi bài toán. Hạn chế là có thể phải mở rộng nhiều ô trên vùng trống hoặc khi G không tiếp cận được. Hàng đợi và thông tin truy vết có thể cần bộ nhớ tỷ lệ với số ô.

## 2.3. Thuật toán DFS

DFS ưu tiên đi sâu theo nhánh đang xét. Chương trình dùng ArrayDeque qua kiểu Deque, thao tác push/pop tạo ngăn xếp LIFO. Ô được đánh dấu ngay khi đưa vào ngăn xếp. Hàng xóm được đẩy theo thứ tự ngược để hướng ưu tiên khi lấy là lên, phải, xuống, trái.

DFS ghi parent khi phát hiện ô mới. Nếu lấy G ra, thuật toán dựng đường qua parent; nếu ngăn xếp cạn mà chưa gặp G, trả không có đường. visited bảo đảm kết thúc trên mê cung có chu trình.

DFS không chọn ô theo khoảng cách đã đi nên có thể gặp G qua một nhánh dài trước khi xét nhánh ngắn. Vì vậy, kết quả của DFS là đường hợp lệ, không có cam kết luôn tối ưu. Một vài ví dụ DFS vẫn có thể cho cùng độ dài với BFS.

## 2.4. Thuật toán A*

### 2.4.1. Hàm đánh giá

A* chọn ô theo f(n) = g(n) + h(n). g(n) là số bước tốt nhất hiện biết từ S đến n; h(n) là ước lượng phần còn lại. Đồ án sử dụng Manhattan:

**h(n) = |row(n) − row(G)| + |col(n) − col(G)|.**

Chỉ đi bốn hướng nên đường thực tế không thể ít hơn tổng chênh lệch hàng và cột. Tường có thể buộc đi vòng nhưng không làm giảm cận dưới này. Giữa hai ô kề nhau, Manhattan chênh không quá 1, do đó heuristic nhất quán với mô hình chi phí của đồ án.

### 2.4.2. Cấu trúc dữ liệu

AStarSearch dùng PriorityQueue chứa Entry(cell, g, f, order). Comparator sắp theo f tăng dần rồi theo order để giải quyết hòa điểm theo thứ tự thêm. PriorityQueue hỗ trợ Comparator và có thời gian thêm/lấy đầu O(log n). [Tài liệu Java SE 17](https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/PriorityQueue.html).

gScore lưu chi phí tốt nhất; parent lưu ô trước trên đường hiện tại. Khi gặp chi phí nhỏ hơn, thuật toán cập nhật hai Map và thêm Entry mới. Entry cũ vẫn có thể nằm trong hàng đợi. Khi lấy ra, nếu g của Entry khác gScore thì bỏ qua vì đã lỗi thời. closed tiếp tục ngăn mở rộng lặp ô đã xử lý hợp lệ.

### 2.4.3. Điều kiện kết thúc và tối ưu

Chỉ ô vượt qua kiểm tra lỗi thời và closed mới được tính là mở rộng. A* kết thúc khi ô đó là G, không kết thúc ngay khi vừa đưa G vào PriorityQueue. Với Manhattan nhất quán, một ô đã đóng không cần mở lại, và đường tìm được có số bước nhỏ nhất.

Kết luận tối ưu phụ thuộc mô hình bốn hướng, chi phí 1 và heuristic đang dùng. Nếu thêm đường chéo hoặc trọng số, cần xét lại công thức heuristic, cách đóng ô và kiểm thử; không thể giữ nguyên kết luận mà không kiểm tra.

## 2.5. Truy vết và dữ liệu kết quả

AbstractSearch chia sẻ checkCancelled và finish. checkCancelled kiểm tra BooleanSupplier từ bên gọi và cờ interrupt của luồng, ném CancellationException khi cần dừng. finish lần ngược từ G theo parent tới S rồi đảo danh sách.

SearchResult chứa path, expanded, elapsedNanos. List.copyOf bảo vệ hai danh sách khỏi sửa sau khi trả về. found dựa vào path không rỗng; steps trả path.size() − 1, hoặc −1 khi không có đường. Mọi Queue/Stack, visited, parent, gScore và closed đều được tạo mới trong từng lần search, không lưu trạng thái tìm kiếm ở thuộc tính đối tượng.

## 2.6. So sánh

| Tiêu chí | BFS | DFS | A* |
|---|---|---|---|
| Cấu trúc chờ | Queue FIFO | Stack LIFO | PriorityQueue |
| Cách chọn ô | Lớp khoảng cách | Nhánh sâu | g + h |
| Đường hợp lệ | Có | Có | Có |
| Bảo đảm ít bước nhất | Có | Không | Có trong mô hình hiện tại |
| Heuristic | Không | Không | Manhattan |
| Thời gian | O(V + E) | O(V + E) | O((V + E) log V) |
| Bộ nhớ | O(V) | O(V) | O(V + E) |

V là số ô trống, E là số cạnh; mỗi ô có tối đa bốn hàng xóm. Các đánh giá giả sử HashMap/HashSet trung bình O(1). A* giữ cả Entry lỗi thời nên mô tả bộ nhớ theo V + E. Không kết luận A* luôn nhanh hơn BFS vì chi phí heap, thứ tự hòa điểm và cấu trúc mê cung đều ảnh hưởng.

# CHƯƠNG 3. PHÂN TÍCH VÀ THIẾT KẾ HƯỚNG ĐỐI TƯỢNG

## 3.1. Kiến trúc package

| Package | Trách nhiệm | Lớp chính |
|---|---|---|
| model | Tọa độ, lưới, quy tắc dữ liệu | Cell, Maze |
| search | Tìm kiếm và kết quả | SearchAlgorithm, AbstractSearch, BfsSearch, DfsSearch, AStarSearch, SearchResult |
| controller | Sự kiện, worker, hoạt ảnh | MazeController |
| ui | Bố cục, nhận chuột, vẽ lưới | MainFrame, MazePanel |
| io | Đọc/ghi và định dạng | MazeFile |

Main tại package gốc vn.edu.maze khởi động ứng dụng. Cách tổ chức tách dữ liệu – hiển thị – điều phối ở mức đơn giản, không dùng framework MVC. Thuật toán không import Swing nên có thể kiểm tra độc lập bằng JUnit.

## 3.2. Trách nhiệm các lớp

| Lớp | Thành phần tiêu biểu | Trách nhiệm |
|---|---|---|
| Cell | row(), col() | Record bất biến biểu diễn tọa độ |
| Maze | walls, start, goal; neighbors(), copy() | Bảo vệ dữ liệu lưới và tạo bản sao |
| SearchAlgorithm | search(Maze, BooleanSupplier) | Hợp đồng tìm kiếm |
| AbstractSearch | checkCancelled(), finish() | Chia sẻ hủy và truy vết |
| BfsSearch | search() | Tìm theo chiều rộng |
| DfsSearch | search() | Tìm theo chiều sâu |
| AStarSearch | search(), heuristic(), Entry | Tìm theo g + Manhattan |
| SearchResult | path, expanded, elapsedNanos | Kết quả và chỉ số |
| MainFrame | Các điều khiển Swing | Bố trí cửa sổ tiếng Việt |
| MazePanel | paintComponent(), setEditor() | Vẽ và ánh xạ chuột sang ô |
| MazeController | run(), animate(), invalidate() | Điều phối vòng đời tác vụ |
| MazeFile | read(), write() | Lưu trữ và kiểm tra tệp |
| Main | main() | Khởi tạo trên EDT |

Mỗi lớp chính nằm trong một tệp Java riêng. Entry là record private nội bộ AStarSearch, chỉ phục vụ PriorityQueue.

## 3.3. Sơ đồ lớp UML

![Hình 3.1. Quan hệ giữa các lớp chính](uml-bao-cao.png)

Hình 3.1 rút gọn từ mã nguồn. Tam giác rỗng biểu diễn kế thừa/hiện thực; đường nét đứt dùng cho phụ thuộc hoặc hiện thực interface; mũi tên thường thể hiện liên kết sử dụng. Các lớp Swing chuẩn và Entry nội bộ được lược bỏ để dễ đọc khi in. Sơ đồ Mermaid chi tiết nằm trong docs/UML.md.

## 3.4. Bốn đặc trưng OOP

### 3.4.1. Đóng gói

Maze để walls, start và goal ở phạm vi private. Bên ngoài chỉ đổi dữ liệu qua các phương thức như setWall, setStart, setGoal và clearWalls. Các phương thức kiểm tra tọa độ và quy tắc, ví dụ không cho đặt tường trên S/G. Không trả mảng walls trực tiếp giúp tránh bỏ qua kiểm tra.

Cell bất biến; SearchResult sao chép danh sách thành bất biến. Những lựa chọn này giảm thay đổi ngoài ý muốn giữa tính toán và hiển thị. Riêng MainFrame để điều khiển public final nhằm nối sự kiện đơn giản; có thể cải tiến nếu mở rộng quy mô.

### 3.4.2. Trừu tượng

SearchAlgorithm quy định thao tác search nhận Maze và hàm kiểm tra hủy, trả SearchResult. Controller không cần biết bên trong dùng Queue hay PriorityQueue. AbstractSearch gom thao tác chung, giúp mỗi lớp con tập trung vào quy tắc chọn ô.

### 3.4.3. Kế thừa

BfsSearch, DfsSearch và AStarSearch kế thừa AbstractSearch, dùng chung phần hủy/truy vết và ghi đè search. MainFrame kế thừa JFrame; MazePanel kế thừa JPanel và ghi đè paintComponent để vẽ lưới.

### 3.4.4. Đa hình

Biến algorithm trong controller có kiểu SearchAlgorithm, nhưng đối tượng thực tế được chọn từ ba lớp thuật toán. Cùng lời gọi algorithm.search(snapshot, this::isCancelled) sẽ thực hiện cách tìm theo đối tượng lúc chạy. Đây là vị trí minh họa đa hình trực tiếp trong mã nguồn.

## 3.5. Mô hình trạng thái

| Trạng thái | Biểu diễn | Chuyển tiếp chính |
|---|---|---|
| Sẵn sàng | busy = false | Chạy → đang tìm |
| Đang tìm | busy = true; worker chạy | Có kết quả → hoạt ảnh; Hủy → đã hủy |
| Đang hoạt ảnh | busy = true; Timer chạy | Hết danh sách → hoàn thành |
| Hoàn thành | busy = false; còn hình kết quả | Chạy lại, chỉnh hoặc đặt lại |
| Đã hủy | busy = false; mã phiên tăng | Chạy lại hoặc đặt lại |

Các tên trạng thái phục vụ phân tích; mã không có enum trạng thái riêng. busy điều khiển khả năng sửa/chạy; worker và animation phản ánh công việc thực thi. Tạo, mở, xóa hoặc đặt lại sẽ vô hiệu hóa phiên trước khi thay đổi dữ liệu.

## 3.6. Luồng tìm kiếm và xử lý đồng thời

Luồng chương trình: nhấn Chạy → invalidate phiên cũ → xóa kết quả → Maze.copy → chọn SearchAlgorithm → SwingWorker chạy search → done trên EDT nhận SearchResult → Timer tô expanded rồi path → mở lại điều khiển khi xong.

Theo tài liệu Java SE 17, doInBackground chạy ở worker thread, còn done chạy trên EDT; thành phần Swing cần được truy cập trên EDT. [Tài liệu SwingWorker](https://docs.oracle.com/en/java/javase/17/docs/api/java.desktop/javax/swing/SwingWorker.html). Main dùng SwingUtilities.invokeLater để tạo cửa sổ; sự kiện nút và Timer cũng xử lý trên EDT.

Mỗi lần chạy giữ token bằng generation hiện tại. invalidate tăng generation, gọi cancel(true), dừng Timer và bỏ trạng thái bận. done và Timer kiểm tra token trước khi cập nhật, nên kết quả cũ hoàn thành muộn bị bỏ qua. Hủy vừa gửi yêu cầu ngắt vừa dựa vào kiểm tra hợp tác trong vòng lặp thuật toán.

Bản sao Maze có mảng tường riêng giúp worker không đọc mô hình đang bị thay bởi thao tác tạo hoặc mở mê cung. Trong lúc busy, công cụ sửa bằng chuột bị khóa; các thao tác thay mê cung vẫn có thể hủy phiên hiện tại một cách có kiểm soát.

## 3.7. Thiết kế lưu trữ

MazeFile dùng định dạng MAZE 1 và UTF-8, giới hạn 64 KiB. Reader kiểm tra tiêu đề, số nguyên, kích thước, tọa độ, số dòng/cột và ký tự. Các ô tường trên S/G bị từ chối thông qua Maze.

Reader tạo một Maze mới và chỉ trả về khi dữ liệu hoàn chỉnh. Controller gọi replace sau khi đọc thành công, nên tệp lỗi không thay dữ liệu đang dùng. Writer lưu mô hình; controller chịu trách nhiệm hỏi trước khi ghi đè. Cách tách này cho phép kiểm thử tệp không phụ thuộc hộp thoại Swing.

# CHƯƠNG 4. XÂY DỰNG VÀ SỬ DỤNG ỨNG DỤNG

## 4.1. Công nghệ

| Thành phần | Lựa chọn | Vai trò |
|---|---|---|
| Ngôn ngữ / bytecode | Java 17, release 17 | Record, Collections và mã ứng dụng |
| Giao diện | Swing | Cửa sổ, nút, slider, vẽ lưới |
| Tìm kiếm nền | SwingWorker | Tính toán ngoài EDT |
| Hoạt ảnh | javax.swing.Timer | Cập nhật theo nhịp trên EDT |
| Build | Maven 3.9.9 khi kiểm chứng | Biên dịch, test, đóng gói |
| Kiểm thử | JUnit Jupiter 5.11.4 | Assertion, ngoại lệ, thư mục tạm |
| Đóng gói | maven-jar-plugin 3.4.2 | Main class vn.edu.maze.Main |

Ứng dụng chạy bằng JDK, không có thư viện runtime ngoài. JUnit chỉ ở scope test. Mã chính và mã kiểm thử nằm trong src/main/java và src/test/java; sản phẩm tạo trong target theo quy trình Maven. [Hướng dẫn Maven](https://maven.apache.org/guides/getting-started/maven-in-five-minutes.html).

## 4.2. Giao diện chính

![Hình 4.1. Giao diện sau khi hoàn tất tìm đường](giao-dien.png)

Hình 4.1 được xuất từ cửa sổ Swing đang hiển thị trong UiSmokeTest bằng view.paint, không phải ảnh thiết kế. Hình minh họa lưới 5×5, A* và đường dài 8 bước. Thời gian trên ảnh là phép đo của riêng lần chạy khi chụp, không đại diện hiệu năng trung bình.

Cột trái chứa kích thước, công cụ chuột, thuật toán, các nút, tốc độ và chú giải. Vùng chính là lưới; bên dưới là thống kê và trạng thái. Xám biểu diễn tường, trắng là ô trống, xanh dương là ô mở rộng, vàng là đường đi, xanh lá là S và đỏ là G.

Khi ô đủ lớn từ 14 pixel, chương trình vẽ thêm chữ S/G. Ô nhỏ hơn ẩn chữ để tránh chồng ký tự nhưng vẫn giữ màu. MazePanel tính ô được chọn dựa trên vị trí lưới sau khi co giãn cửa sổ.

## 4.3. Các bước thao tác

1. Nhập số hàng/cột hợp lệ, bấm Tạo lưới hoặc mở mê cung mẫu.
2. Chọn Vẽ tường/Xóa tường để nhấn hoặc kéo; chọn Đặt S/Đặt G và nhấn ô trống.
3. Chọn BFS, DFS hoặc A*, bấm Chạy; không chỉnh ô khi chương trình bận.
4. Xem ô mở rộng, đường đi và số liệu; điều chỉnh tốc độ hoặc Hủy.
5. Đặt lại kết quả để thử thuật toán khác trên cùng mê cung; Xóa mê cung để xóa tường nhưng giữ S/G.
6. Lưu tệp nếu cần giữ dữ liệu. Xác nhận khi chọn đường dẫn đã có tệp.

Tạo và mở thành công thay dữ liệu hiện tại. Phiên bản chưa cảnh báo thay đổi chưa lưu khi tạo/mở/thoát, nên cần chủ động lưu trước.

## 4.4. Hoạt ảnh và thống kê

Thuật toán tính xong trước rồi Timer phát lại expanded và path. Tốc độ cao xử lý nhiều ô mỗi nhịp; tốc độ thấp giảm số ô và tăng khoảng chờ. Nhờ phát lại tách biệt, tốc độ hoạt ảnh không ảnh hưởng thời gian thuật toán hiển thị.

Số bước bằng số cạnh. Ô mở rộng gồm các ô lấy hợp lệ khỏi cấu trúc chờ, kể cả S/G nếu tìm thấy; Entry lỗi thời A* không được tính. System.nanoTime đo từ đầu search đến giá trị elapsedNanos sau truy vết, không gồm sao chép Maze, thời gian chờ worker hoặc hoạt ảnh. Chưa thực hiện benchmark có khởi động JVM và thống kê nhiều lượt.

## 4.5. Xử lý lỗi và thông báo

| Tình huống | Cách xử lý |
|---|---|
| Kích thước sai / ngoài giới hạn | Báo lỗi, không thay mê cung |
| Tường trên S/G | Từ chối, giải thích ở thanh trạng thái |
| Đặt S/G trên tường | Từ chối qua quy tắc của Maze |
| Không có đường | Hoàn tất hoạt ảnh và báo không có đường |
| Tệp không hợp lệ / không đọc được | Hộp thoại lỗi, giữ dữ liệu hiện tại |
| Không ghi được | Báo lỗi lưu tệp |
| Hủy | Dừng worker/Timer, giữ hình đang xem |

## 4.6. Ví dụ tệp mê cung

```text
MAZE 1
5 5
0 0
4 4
.....
.###.
...#.
.#...
.....
```

Tọa độ từ 0. Dấu chấm là ô trống, # là tường. S/G lưu ở tiêu đề, không ghi bằng chữ trong lưới. Tệp yêu cầu đúng số dòng/cột và hai số nguyên ở mỗi dòng thông tin; không chấp nhận chú thích hay dòng dư.

# CHƯƠNG 5. KIỂM THỬ VÀ ĐÁNH GIÁ KẾT QUẢ

## 5.1. Mục tiêu và môi trường

Kiểm thử tập trung vào đường đi hợp lệ, tối ưu của BFS/A*, chu trình, không có đường, dữ liệu lưu trữ và vòng đời tác vụ. JUnit 5 cung cấp assertion và kiểm tra ngoại lệ, giúp diễn đạt điều kiện mong đợi trong mã test. [JUnit User Guide 5.11.4](https://docs.junit.org/5.11.4/user-guide/).

| Thành phần | Môi trường thực tế |
|---|---|
| Ngày chạy lại để đối chiếu báo cáo | 05/11/2026 |
| Hệ điều hành | Windows, có màn hình để chạy Swing |
| JDK chạy build/test | Eclipse Temurin 21.0.11 |
| Mức biên dịch | release 17, bytecode major version 61 |
| Maven / JUnit | Maven 3.9.9; JUnit Jupiter 5.11.4 |
| Minh chứng | docs/build.log; target/surefire-reports |

Biên dịch release 17 xác định mức API/bytecode, không thay thế việc kiểm tra trực tiếp trên runtime Java 17. Các kết quả dưới đây ứng với mã và log lưu cùng báo cáo.

## 5.2. Các kiểm thử đã triển khai

| STT | Trường hợp (lớp kiểm thử) | Nội dung | Kết quả |
|---|---|---|---|
| 1 | Đường tránh tường (SearchTest) | Đường kề cạnh, không xuyên tường; BFS 14 bước ở ví dụ | Đạt |
| 2 | Không có đường (SearchTest) | Tường chắn ngang; ba thuật toán báo không có đường | Đạt |
| 3 | S trùng G (SearchTest) | Một ô, 0 bước, một ô mở rộng | Đạt |
| 4 | Có chu trình (SearchTest) | Đường hợp lệ; không mở rộng lặp | Đạt |
| 5 | Chạy nhiều lần (SearchTest) | Dùng lại đối tượng, không giữ trạng thái cũ | Đạt |
| 6 | 150 mẫu ngẫu nhiên (SearchTest) | So BFS/A*, kiểm tra DFS trên 150 mẫu | Đạt |
| 7 | Hủy và chạy lại (SearchTest) | Yêu cầu hủy sinh ngoại lệ; sau đó chạy lại được | Đạt |
| 8 | Lưới lớn nhất (SearchTest) | Lưới 100×100; BFS 198 bước | Đạt |
| 9 | Ràng buộc dữ liệu (MazeTest) | Giới hạn lưới, tọa độ, đầu/cuối | Đạt |
| 10 | Bản sao độc lập (MazeTest) | Sửa bản sao không đổi bản gốc | Đạt |
| 11 | Lưu rồi đọc (MazeFileTest) | Giữ kích thước, S/G, từng ô | Đạt |
| 12 | Sai định dạng (MazeFileTest) | Tiêu đề, số, dòng/cột, ký tự, tường tại S, tệp lớn sai quy định | Đạt |
| 13 | Tệp không tồn tại (MazeFileTest) | Phát sinh IOException | Đạt |
| 14 | Vòng đời giao diện (UiSmokeTest) | Cửa sổ thật, chạy/đặt lại/chạy mới/hủy hoạt ảnh | Đạt |

14 là số phương thức JUnit ghi nhận, không phải tổng đầu vào hay tổng assertion. Một phương thức có thể thử nhiều mê cung hoặc nhiều chuỗi lỗi.

## 5.3. Đối chiếu 150 mê cung ngẫu nhiên

Bộ test dùng Random với seed 20261103L. Mỗi mẫu có hàng và cột độc lập trong khoảng 5–30; ô thường có xác suất tường 0,29; S/G giữ trống. Seed cố định giúp tái lập cùng dữ liệu.

Với mỗi mẫu, test so found và steps của BFS/A*. DFS được so khả năng đến đích với BFS. Khi có đường, hàm valid kiểm tra đầu/cuối đúng, mọi ô trong biên và không là tường, hai ô liên tiếp cách Manhattan 1, không lặp ô trên đường và trong danh sách mở rộng.

Cả 150 mẫu vượt qua các điều kiện trên. Báo cáo không đưa số mẫu có đường/bế tắc hoặc thời gian trung bình vì test không xuất những thống kê này. Thử ngẫu nhiên tăng độ tin cậy nhưng không thay thế lập luận lý thuyết.

## 5.4. Kết quả build và kiểm thử UI

Log ghi **BUILD SUCCESS; Tests run: 14, Failures: 0, Errors: 0, Skipped: 0**. Theo lớp, SearchTest có 8 phương thức, MazeTest có 2, MazeFileTest có 3, UiSmokeTest có 1. JAR ở target/maze-search-1.0.0.jar.

UiSmokeTest tạo cửa sổ thật và gọi doClick trên EDT. Test chạy BFS lưới 5×5, xác nhận 8 bước, tạo tác vụ lưới lớn rồi đặt lại, chạy A* mới, kiểm tra thống kê, hủy hoạt ảnh chậm và đặt lại kết quả. Ảnh báo cáo được xuất từ test này. Trên máy headless, bài Swing có điều kiện bỏ qua; lần chạy dẫn trong báo cáo không bỏ qua bài nào.

## 5.5. Đánh giá và phần chưa kiểm chứng

Các trường hợp đã chạy xác nhận quy tắc đường đi, độ dài, lưu/đọc và điều khiển tác vụ. Tách search khỏi Swing cho phép kiểm tra nhiều đầu vào mà không cần thao tác giao diện.

UI test chưa bao phủ đầy đủ hộp thoại mở/lưu, xác nhận ghi đè và thao tác chuột. Test hủy thuật toán kiểm tra yêu cầu hủy có sẵn từ đầu; UI test kiểm tra thêm hủy hoạt ảnh và đặt lại tác vụ. Chưa có thử tải kéo dài, đánh giá khả năng tiếp cận hoặc benchmark. Chưa chạy trực tiếp bằng JDK 17, Linux/macOS. Các giới hạn này được phân biệt với nội dung đã kiểm chứng.

# CHƯƠNG 6. TỔ CHỨC THỰC HIỆN VÀ PHÂN CÔNG NHÓM

## 6.1. Nguyên tắc phân công

Nhóm ba thành viên chia theo mô hình/lưu trữ, thuật toán và giao diện/điều phối. Mỗi người cần nắm hợp đồng SearchAlgorithm, Maze và SearchResult để kết nối phần phụ trách. A*, hủy tác vụ và kiểm tra tệp cần cả nhóm rà soát.

Bảng sau là phương án phân công để tiếp nhận và hoàn thiện đồ án. Chưa có thông tin tên và lịch sử làm việc nên báo cáo không khẳng định đây là đóng góp đã diễn ra. Trước khi nộp, nhóm điền người phụ trách thật và điều chỉnh nội dung; không tự thêm tỷ lệ hoàn thành hoặc ngày làm việc chưa có minh chứng.

## 6.2. Bảng phân công cho ba thành viên

| Thành viên | Phần phụ trách đề xuất | Sản phẩm cần nắm / hoàn thiện |
|---|---|---|
| SV1 – [Họ tên, MSSV] | Yêu cầu; model/io; test dữ liệu và tệp | Cell, Maze, MazeFile, MazeTest, MazeFileTest; chương 1 và lưu trữ |
| SV2 – [Họ tên, MSSV] | Lý thuyết; ba thuật toán; test đường đi | SearchAlgorithm, AbstractSearch, BfsSearch, DfsSearch, AStarSearch, SearchResult, SearchTest; chương 2 |
| SV3 – [Họ tên, MSSV] | Swing; điều phối; đóng gói; tổng hợp báo cáo | Main, MainFrame, MazePanel, MazeController, UiSmokeTest, pom.xml và script; chương 3–5 |
| Cả nhóm | Tích hợp, kiểm chứng tài liệu, diễn tập | Chạy test, kiểm tra mẫu, xác nhận phân công |

## 6.3. Trình tự phối hợp đề xuất

| Giai đoạn | Công việc | Điều kiện hoàn thành |
|---|---|---|
| 1 | Thống nhất yêu cầu và quy tắc | Cả nhóm giải thích thống nhất đầu vào/đầu ra |
| 2 | Đọc hợp đồng và dữ liệu chung | Gọi đúng API giữa các phần |
| 3 | Hoàn thiện phần phụ trách | Test liên quan đạt; hiểu và giải thích được mã |
| 4 | Tích hợp và so báo cáo | Build đạt; không mô tả chức năng chưa có |
| 5 | Điền thông tin, thử demo | Ba người đều chạy và trình bày được |

Đây là trình tự đề xuất, không phải nhật ký tiến độ đã xác nhận. Chỉ bổ sung ngày thực hiện nếu có dữ liệu thực tế và giảng viên yêu cầu.

## 6.4. Phân chia trình bày

| Người | Nội dung | Minh họa |
|---|---|---|
| Sinh viên 1 | Bài toán, yêu cầu, dữ liệu và đóng gói | Tạo/sửa/lưu/mở; kiểm tra dữ liệu |
| Sinh viên 2 | BFS, DFS, A*, tính tối ưu và test | Cùng mê cung; parent, visited, gScore |
| Sinh viên 3 | GUI, đa hình, xử lý nền, kết quả và hạn chế | Hủy/chạy lại; token và generation |

Mỗi thành viên cần trả lời được câu hỏi cơ bản của phần khác, không chỉ học nội dung thuyết trình của mình. Nhóm nên thử sửa một quy tắc nhỏ và chạy lại test để củng cố khả năng đọc mã.

# CHƯƠNG 7. KẾT LUẬN VÀ HƯỚNG PHÁT TRIỂN

## 7.1. Kết quả đạt được

Ứng dụng có đầy đủ luồng tạo/sửa mê cung, chọn thuật toán, xem hoạt ảnh, thống kê, hủy/đặt lại và lưu/mở. Giao diện tiếng Việt có chú giải; thuật toán tách khỏi Swing để kiểm tra độc lập.

Thiết kế thể hiện đóng gói qua Maze, trừu tượng qua SearchAlgorithm và AbstractSearch, kế thừa qua các thuật toán và đa hình tại controller. Bộ test gồm tình huống biên và 150 mê cung ngẫu nhiên có seed. Sản phẩm đáp ứng mục tiêu học phần trong phạm vi lưới bốn hướng.

## 7.2. Hạn chế

Chưa có hoàn tác, zoom, sinh mê cung tự động trong UI, trọng số hoặc đi chéo. Lưới 100×100 có ô nhỏ nên thao tác khó. Chưa cảnh báo chưa lưu trước khi tạo/mở/thoát.

Hoạt ảnh phát lại sau tìm kiếm, chưa truyền từng bước trực tiếp. Đọc/ghi tệp chạy trên EDT; dù giới hạn tệp nhỏ, ổ mạng chậm vẫn có thể gây chờ. Ghi tệp chưa dùng tệp tạm/đổi tên nguyên tử nên lỗi thiết bị lúc lưu có thể để tệp dở.

Controller truy cập trực tiếp một số điều khiển public final của MainFrame để giữ mã đơn giản; khi mở rộng có thể thay bằng API sự kiện rõ ràng hơn. Số liệu thời gian hiện tại chỉ phục vụ quan sát, chưa đủ kết luận hiệu năng tổng quát.

## 7.3. Hướng phát triển

Ưu tiên bổ sung cảnh báo chưa lưu và lưu an toàn; tiếp theo là zoom/hoàn tác, kiểm thử UI đầy đủ và kiểm chứng đa nền tảng. Sinh mê cung có seed và xuất thống kê nhiều lượt có thể hỗ trợ so sánh thực nghiệm.

Nếu thêm trọng số hoặc đường chéo, cần cập nhật mô hình cạnh, cách tính độ dài, heuristic, điều kiện tối ưu và test. Đây là hướng phát triển, không phải chức năng hiện có.

## 7.4. Kết luận

Đồ án kết nối hướng đối tượng, cấu trúc dữ liệu, thuật toán và giao diện trong chương trình có thể chạy và kiểm tra. Giá trị học tập chính là hiểu cách nhiều thuật toán thực hiện cùng hợp đồng, lý do bảo vệ dữ liệu và cách quản lý vòng đời tác vụ nền. Đọc mã, xác nhận phân công và diễn tập các tình huống thực tế sẽ giúp nhóm trình bày chủ động.

# TÀI LIỆU THAM KHẢO

[1] Oracle. [SwingWorker – Java SE 17 API](https://docs.oracle.com/en/java/javase/17/docs/api/java.desktop/javax/swing/SwingWorker.html). Đối chiếu worker, EDT và vòng đời tác vụ. Truy cập ngày 05/11/2026.

[2] Oracle. [PriorityQueue – Java SE 17 API](https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/PriorityQueue.html). Đối chiếu Comparator và hàng đợi ưu tiên. Truy cập ngày 05/11/2026.

[3] Apache Maven Project. [Maven in 5 Minutes](https://maven.apache.org/guides/getting-started/maven-in-five-minutes.html). Tham khảo cấu trúc và build. Truy cập ngày 05/11/2026.

[4] JUnit Team. [JUnit 5 User Guide 5.11.4](https://docs.junit.org/5.11.4/user-guide/). Tham khảo assertion, ngoại lệ và kiểm thử. Truy cập ngày 05/11/2026.

[5] Mã nguồn nội bộ: src/main/java, src/test/java và pom.xml. Nguồn đối chiếu thiết kế, thuật toán và chức năng thực tế.

[6] Minh chứng nội bộ: docs/build.log, docs/KIEM_THU.md, docs/giao-dien.png và target/surefire-reports. Nguồn đối chiếu kết quả đã chạy; không có số liệu benchmark giả định.

# PHỤ LỤC A. CÀI ĐẶT VÀ CHẠY CHƯƠNG TRÌNH

## A.1. Yêu cầu cài đặt

Cài JDK 17 trở lên và thêm java vào PATH. Muốn build cần Maven 3.9 trở lên hoặc Maven cục bộ trong workspace. Kiểm tra:

```powershell
java -version
javac -version
mvn -version
```

Lần build đầu có thể cần Internet tải plugin/JUnit. Chạy GUI cần môi trường đồ họa.

## A.2. Chạy nhanh trên Windows

Mở terminal ở đúng thư mục dự án. Với workspace hiện tại:

```powershell
cd "C:\Users\ASUS\Documents\School\New folder\Huongdoituong"
.\run.bat
```

Hoặc gọi từ thư mục bất kỳ:

```powershell
& "C:\Users\ASUS\Documents\School\New folder\Huongdoituong\run.bat"
```

Sửa đường dẫn nếu chuyển dự án. Lệnh .\run.bat chỉ tìm script tại thư mục đang đứng; lỗi “not recognized” khi đang ở database cần xử lý bằng đổi thư mục hoặc đường dẫn đầy đủ.

## A.3. Build và test

```powershell
mvn clean package
mvn test
java -jar target/maze-search-1.0.0.jar
```

Maven cục bộ trong workspace:

```powershell
.\.tools\apache-maven-3.9.9\bin\mvn.cmd clean package
```

Linux/macOS dùng mvn clean package rồi sh run.sh; chưa được kiểm chứng trong phiên bàn giao. Khi chuyển JAR và script sang máy khác, giữ đúng target/maze-search-1.0.0.jar.

## A.4. Cấu trúc bàn giao

```text
pom.xml, README.md, run.bat, run.sh
src/main/java/vn/edu/maze/
  Main.java
  model/       Cell, Maze
  search/      SearchAlgorithm, AbstractSearch, SearchResult
               BfsSearch, DfsSearch, AStarSearch
  controller/  MazeController
  ui/          MainFrame, MazePanel
  io/          MazeFile
src/test/java/vn/edu/maze/
  model/       MazeTest
  search/      SearchTest
  io/          MazeFileTest
  ui/          UiSmokeTest
samples/       co-duong.txt, khong-co-duong.txt
docs/          Bao cao, UML, anh va log test
target/        maze-search-1.0.0.jar
```

# PHỤ LỤC B. NỘI DUNG CHUẨN BỊ BẢO VỆ

## B.1. Kịch bản trình diễn

1. Chạy run.bat, giới thiệu công cụ, màu và các chỉ số.
2. Mở samples/co-duong.txt, chạy BFS; đặt lại rồi chạy A*. Giải thích cùng tối ưu nhưng có thể khác đường nếu nhiều đường bằng nhau.
3. Chạy DFS, giải thích hợp lệ không có nghĩa luôn ít bước nhất; không hứa mọi ví dụ DFS đều dài hơn.
4. Mở samples/khong-co-duong.txt và chỉ thông báo không có đường.
5. Giảm tốc độ, chạy rồi Hủy; chạy lại hoặc Đặt lại để minh họa vòng đời tác vụ.
6. Mở SearchAlgorithm, AbstractSearch, Maze và MazeController để chỉ bốn đặc trưng OOP.
7. Trình bày log test và bài đối chiếu 150 mê cung, nêu đúng phần chưa kiểm chứng.

## B.2. Câu hỏi thường gặp

| Câu hỏi | Gợi ý trả lời |
|---|---|
| Vì sao BFS ngắn nhất? | FIFO mở rộng theo lớp; mỗi cạnh cùng chi phí 1 |
| Vì sao DFS không luôn tối ưu? | LIFO ưu tiên nhánh sâu, không chọn theo số bước |
| Vì sao dùng Manhattan? | Di chuyển bốn hướng; chênh lệch hàng/cột là cận dưới |
| Khi nào A* dừng? | Lấy G hợp lệ khỏi PriorityQueue, sau kiểm tra lỗi thời/closed |
| Entry lỗi thời là gì? | g trong Entry không còn bằng gScore tốt nhất |
| Vì sao không search trên EDT? | Tính toán có thể chặn sự kiện và vẽ giao diện |
| Kết quả cũ có ghi đè phiên mới? | Token khác generation bị bỏ ở done và Timer |
| Vì sao dùng bản sao Maze? | Worker đọc dữ liệu riêng khi mô hình UI được thay |
| Đường có 9 ô dài bao nhiêu? | 8 bước, số cạnh bằng số ô trừ 1 |
| Làm sao giữ báo cáo đúng mã? | Đối chiếu lớp/phương thức/test/log và tách hướng phát triển |

## B.3. Thông tin cần hoàn thiện trước khi nộp

- Điền trường, khoa, giảng viên, lớp, số nhóm, họ tên và MSSV.
- Xác nhận bảng phân công theo công việc thực tế của ba thành viên.
- Đối chiếu mẫu của khoa nếu có; bản này dùng cấu trúc học phần thông dụng, chưa đối chiếu một mẫu trường riêng.
- Đọc PDF, cập nhật mục lục sau khi sửa Word và chạy thử trên máy dùng bảo vệ.
