# Requires desktop Microsoft Word; creates a formatted DOCX and PDF from BAO_CAO.md.
$ErrorActionPreference = 'Stop'
$reportPath = Join-Path $PSScriptRoot 'BAO_CAO.md'
$htmlPath = Join-Path $PSScriptRoot 'BAO_CAO.html'
$docxPath = Join-Path $PSScriptRoot 'BAO_CAO.docx'
$pdfPath = Join-Path $PSScriptRoot 'BAO_CAO.pdf'
$tempBase=Join-Path $PSScriptRoot ('.bao-cao-'+[Guid]::NewGuid().ToString('N'))
$tempDocx=$tempBase+'.docx'; $tempPdf=$tempBase+'.pdf'
Add-Type -AssemblyName System.Drawing

function Inline([string]$Text) {
    $value = [System.Net.WebUtility]::HtmlEncode($Text)
    $value = [regex]::Replace($value, '\[([^\]]+)\]\(([^)]+)\)', '<a href="$2">$1</a>')
    $value = [regex]::Replace($value, '\*\*(.+?)\*\*', '<b>$1</b>')
    $value = [regex]::Replace($value, '`([^`]+)`', '<code>$1</code>')
    return $value
}

$lines = [System.IO.File]::ReadAllLines($reportPath)
$body = [System.Text.StringBuilder]::new()
$inCover=$false; $inCode=$false; $inTable=$false; $inToc=$false; $tocTitle=$false
$code=[System.Text.StringBuilder]::new()
foreach($line in $lines) {
    if($line -eq '<!-- COVER -->') { $inCover=$true; [void]$body.AppendLine('<div class="cover">'); continue }
    if($line -eq '<!-- /COVER -->') { $inCover=$false; [void]$body.AppendLine('</div>'); continue }
    if($line -eq '<!-- TOC_TITLE -->') { $tocTitle=$true; continue }
    if($line -eq '<!-- TOC -->') { $inToc=$true; [void]$body.AppendLine('<p>__AUTO_TOC__</p>'); continue }
    if($inToc) { if($line.StartsWith('# ')) { $inToc=$false } else { continue } }
    if($line.StartsWith('```')) {
        if($inCode) {
            [void]$body.AppendLine('<pre>'+[System.Net.WebUtility]::HtmlEncode($code.ToString().TrimEnd())+'</pre>')
            [void]$code.Clear(); $inCode=$false
        } else { $inCode=$true }
        continue
    }
    if($inCode) { [void]$code.AppendLine($line); continue }
    if($inTable -and -not $line.StartsWith('|')) { [void]$body.AppendLine('</table>'); $inTable=$false }
    if($line.StartsWith('|')) {
        if($line -match '^\|[\s:|\-]+\|$') { continue }
        $first=-not $inTable
        if($first) { [void]$body.AppendLine('<table>'); $inTable=$true }
        $tag=if($first) { 'th' } else { 'td' }
        $cells=$line.Trim().Trim('|').Split('|')
        $row=($cells | ForEach-Object { '<'+$tag+'>'+(Inline $_.Trim())+'</'+$tag+'>' }) -join ''
        [void]$body.AppendLine('<tr>'+$row+'</tr>'); continue
    }
    if([string]::IsNullOrWhiteSpace($line)) { continue }
    if($line -eq '---') { [void]$body.AppendLine('<p class="rule">____________________________</p>'); continue }
    if($line -match '^!\[(.+)\]\((.+)\)$') {
        $caption=Inline $Matches[1]; $imageFile=Join-Path $PSScriptRoot $Matches[2]
        if(-not (Test-Path -LiteralPath $imageFile)) { throw "Missing image: $imageFile" }
        $imageUrl=([Uri]$imageFile).AbsoluteUri
        $sourceImage=[Drawing.Image]::FromFile($imageFile)
        try { $imageHeight=[int][Math]::Round(565*$sourceImage.Height/$sourceImage.Width) } finally { $sourceImage.Dispose() }
        [void]$body.AppendLine('<p class="figure"><img src="'+$imageUrl+'" width="565" height="'+$imageHeight+'"></p><p class="caption">'+$caption+'</p>'); continue
    }
    if($line -match '^(#{1,3})\s+(.+)$') {
        $level=$Matches[1].Length; $title=Inline $Matches[2]
        if($tocTitle) { [void]$body.AppendLine('<p class="toc-title">'+$title+'</p>'); $tocTitle=$false; continue }
        $css=if($level -eq 1) { ' class="chapter"' } else { '' }
        [void]$body.AppendLine('<h'+$level+$css+'>'+$title+'</h'+$level+'>'); continue
    }
    $paragraphClass=''
    if($inCover) { $paragraphClass=' class="coverline"' }
    elseif($line -match '^\d+\.\s|^-\s') { $paragraphClass=' class="item"' }
    [void]$body.AppendLine('<p'+$paragraphClass+'>'+(Inline $line)+'</p>')
}
if($inTable) { [void]$body.AppendLine('</table>') }
$html=@'
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Bao cao do an</title>
<style>
@page { size:21cm 29.7cm; margin:2cm 2cm 2cm 3cm; }
body { font-family:"Times New Roman"; font-size:13pt; color:#111; }
p { margin:0 0 7pt 0; text-align:justify; line-height:150%; }
h1 { font-size:16pt; color:#142d4e; margin:0 0 16pt; page-break-before:always; page-break-after:avoid; }
h2 { font-size:14pt; color:#142d4e; margin:14pt 0 8pt; page-break-after:avoid; }
h3 { font-size:13pt; margin:10pt 0 6pt; page-break-after:avoid; }
.cover { text-align:center; }
.coverline { text-align:center; line-height:145%; margin:0 0 14pt; font-size:14pt; }
.rule { text-align:center; margin-bottom:28pt; }
table { border-collapse:collapse; width:100%; margin:8pt 0 12pt; font-size:11pt; }
td,th { border:1px solid #63758a; padding:6pt; text-align:left; vertical-align:top; line-height:125%; }
th { background:#e8eef5; font-weight:bold; }
pre { font-family:Consolas; font-size:9pt; white-space:pre-wrap; background:#f1f3f5; padding:8pt; line-height:120%; }
code { font-family:Consolas; font-size:10pt; }
.figure { text-align:center; page-break-after:avoid; }
.caption { text-align:center; font-size:11pt; font-style:italic; margin:6pt 0 12pt; }
.toc-title { font-size:16pt; font-weight:bold; color:#142d4e; page-break-before:always; margin:0 0 16pt; }
.item { margin-left:12pt; }
a { color:#173d72; }
</style></head><body>
'@
[System.IO.File]::WriteAllText($htmlPath,$html+$body.ToString()+'</body></html>',[System.Text.UTF8Encoding]::new($false))

$word=$null; $document=$null
try {
    Write-Output 'Starting Word'
    $word=New-Object -ComObject Word.Application
    $word.Visible=$false; $word.DisplayAlerts=0
    $word.Options.SavePropertiesPrompt=$false
    $word.Options.BackgroundSave=$false
    Write-Output 'Opening HTML'
    $document=$word.Documents.Open($htmlPath,$false,$false)
    $document.PageSetup.PaperSize=7 # A4
    $document.PageSetup.TopMargin=$word.CentimetersToPoints(2)
    $document.PageSetup.BottomMargin=$word.CentimetersToPoints(2)
    $document.PageSetup.LeftMargin=$word.CentimetersToPoints(3)
    $document.PageSetup.RightMargin=$word.CentimetersToPoints(2)
    $document.PageSetup.DifferentFirstPageHeaderFooter=$true
    $normal=$document.Styles.Item(-1)
    $normal.Font.Name='Times New Roman'; $normal.Font.Size=13
    $normal.ParagraphFormat.WidowControl=$true
    $normal.ParagraphFormat.LineSpacingRule=1 # 1.5 lines
    $normal.ParagraphFormat.SpaceAfter=6
    foreach($styleId in @(-2,-3,-4)) {
        $heading=$document.Styles.Item($styleId)
        $heading.Font.Name='Times New Roman'
        $heading.ParagraphFormat.KeepWithNext=$true
    }
    $document.Styles.Item(-2).ParagraphFormat.PageBreakBefore=$true
    Write-Output 'Formatting tables'
    foreach($table in $document.Tables) {
        $table.AllowAutoFit=$true; $table.AutoFitBehavior(2)
        $table.Rows.AllowBreakAcrossPages=$false
        $table.Rows.Item(1).HeadingFormat=$true
        $table.Range.Font.Name='Times New Roman'; $table.Range.Font.Size=11
        $table.Range.ParagraphFormat.LineSpacingRule=0
        $table.Range.ParagraphFormat.SpaceBefore=0
        $table.Range.ParagraphFormat.SpaceAfter=2
    }
    $maxWidth=$document.PageSetup.PageWidth-$document.PageSetup.LeftMargin-$document.PageSetup.RightMargin
    foreach($image in $document.InlineShapes) {
        $image.LockAspectRatio=-1
        if($image.Width -gt $maxWidth) { $image.Width=$maxWidth }
    }
    Write-Output 'Building table of contents'
    $tocRange=$document.Content.Duplicate
    if(-not $tocRange.Find.Execute('__AUTO_TOC__')) { throw 'TOC placeholder not found' }
    $tocRange.Text=''
    $toc=$document.TablesOfContents.Add($tocRange,$true,1,2)
    $toc.Range.Font.Name='Times New Roman'; $toc.Range.Font.Size=12
    $toc.Range.ParagraphFormat.LineSpacingRule=0
    $toc.Range.ParagraphFormat.SpaceBefore=0
    $toc.Range.ParagraphFormat.SpaceAfter=3
    $footer=$document.Sections.Item(1).Footers.Item(1).Range
    $footer.ParagraphFormat.Alignment=1
    $footer.Font.Name='Times New Roman'; $footer.Font.Size=11
    [void]$footer.Fields.Add($footer,-1,'PAGE')
    $document.Sections.Item(1).Footers.Item(1).Range.ParagraphFormat.Alignment=1
    Write-Output 'Updating pagination'
    $document.Repaginate(); $toc.Update()
    $toc.Range.Font.Name='Times New Roman'; $toc.Range.Font.Size=12
    $toc.Range.ParagraphFormat.LineSpacingRule=0
    $toc.Range.ParagraphFormat.SpaceBefore=0
    $toc.Range.ParagraphFormat.SpaceAfter=3
    $toc.Range.ParagraphFormat.KeepWithNext=$false
    $document.Repaginate(); $toc.UpdatePageNumbers()
    Write-Output 'Saving DOCX'
    $document.SaveAs2([string]$tempDocx,16)
    Write-Output 'Exporting PDF'
    $document.ExportAsFixedFormat([string]$tempPdf,17)
    $pages=$document.ComputeStatistics(2)
    $summary=[ordered]@{
        pages=$pages; tables=$document.Tables.Count; images=$document.InlineShapes.Count
        toc=$document.TablesOfContents.Count; word_version=$word.Version
        font='Times New Roman'; font_size=13; paper='A4'; margins_cm='top=2; bottom=2; left=3; right=2'
        markdown=$reportPath; docx=$docxPath; pdf=$pdfPath
    }
    $summary | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'bao-cao-export.json') -Encoding UTF8
    $summary | ConvertTo-Json
} finally {
    if($null -ne $document) { $document.Close(0); [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($document) }
    if($null -ne $word) { $word.Quit(); [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($word) }
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
}
Copy-Item -LiteralPath $tempDocx -Destination $docxPath -Force
Copy-Item -LiteralPath $tempPdf -Destination $pdfPath -Force
Remove-Item -LiteralPath $tempDocx,$tempPdf -Force
