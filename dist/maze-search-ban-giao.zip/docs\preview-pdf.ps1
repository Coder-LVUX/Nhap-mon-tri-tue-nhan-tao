param([int[]]$Pages=@(1,3,14,19))
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null=[Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]
$null=[Windows.Data.Pdf.PdfDocument,Windows.Data.Pdf,ContentType=WindowsRuntime]
$null=[Windows.Storage.Streams.InMemoryRandomAccessStream,Windows.Storage.Streams,ContentType=WindowsRuntime]
$null=[Windows.Storage.Streams.DataReader,Windows.Storage.Streams,ContentType=WindowsRuntime]
$asyncMethod=[System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetGenericArguments().Count -eq 1 -and $_.GetParameters().Count -eq 1 } | Select-Object -First 1
$actionMethod=[System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and -not $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' } | Select-Object -First 1
function AwaitResult($Operation,[Type]$ResultType) {
    $task=$asyncMethod.MakeGenericMethod($ResultType).Invoke($null,@($Operation))
    $task.Wait(); return $task.Result
}
$pdfPath=Join-Path $PSScriptRoot 'BAO_CAO.pdf'
$file=AwaitResult ([Windows.Storage.StorageFile]::GetFileFromPathAsync($pdfPath)) ([Windows.Storage.StorageFile])
$pdf=AwaitResult ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($file)) ([Windows.Data.Pdf.PdfDocument])
$previewDir=Join-Path (Split-Path $PSScriptRoot -Parent) '.tools/report-preview'
New-Item -ItemType Directory -Force $previewDir | Out-Null
foreach($number in $Pages) {
    $page=$pdf.GetPage($number-1)
    $stream=[Windows.Storage.Streams.InMemoryRandomAccessStream]::new()
    try {
        $render=$actionMethod.Invoke($null,@($page.RenderToStreamAsync($stream))); $render.Wait()
        $reader=[Windows.Storage.Streams.DataReader]::new($stream.GetInputStreamAt(0))
        try {
            $null=AwaitResult ($reader.LoadAsync([uint32]$stream.Size)) ([uint32])
            $bytes=[byte[]]::new($stream.Size); $reader.ReadBytes($bytes)
            $output=Join-Path $previewDir ('trang-'+$number+'.png')
            [IO.File]::WriteAllBytes($output,$bytes); Write-Output $output
        } finally { $reader.Dispose() }
    } finally { $stream.Dispose(); $page.Dispose() }
}
Write-Output ('PDF pages: '+$pdf.PageCount)
