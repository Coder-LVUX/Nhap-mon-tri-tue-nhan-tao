param([string]$OutputPath = (Join-Path $PSScriptRoot 'uml-bao-cao.png'))
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$bitmap = [Drawing.Bitmap]::new(1600,1380)
$graphics = [Drawing.Graphics]::FromImage($bitmap)
$graphics.Clear([Drawing.Color]::White)
$graphics.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
$graphics.TextRenderingHint = [Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$pen = [Drawing.Pen]::new([Drawing.Color]::FromArgb(55,65,80),3)
$dash = [Drawing.Pen]::new([Drawing.Color]::FromArgb(55,65,80),3)
$dash.DashStyle = [Drawing.Drawing2D.DashStyle]::Dash
$titleFont = [Drawing.Font]::new('Arial',22,[Drawing.FontStyle]::Bold)
$font = [Drawing.Font]::new('Arial',18)
$smallFont = [Drawing.Font]::new('Arial',16)
function Link([int[]]$Coordinates, [bool]$Dashed=$false, [bool]$Triangle=$false) {
    $points = for($i=0;$i -lt $Coordinates.Length;$i+=2) { [Drawing.Point]::new($Coordinates[$i],$Coordinates[$i+1]) }
    $currentPen = if($Dashed) { $dash } else { $pen }
    $graphics.DrawLines($currentPen,[Drawing.Point[]]$points)
    $end=$points[-1]; $previous=$points[-2]
    $angle=[Math]::Atan2($end.Y-$previous.Y,$end.X-$previous.X)
    $length=18; $width=9
    $baseX=$end.X-$length*[Math]::Cos($angle); $baseY=$end.Y-$length*[Math]::Sin($angle)
    $left=[Drawing.PointF]::new(($baseX+$width*[Math]::Sin($angle)),($baseY-$width*[Math]::Cos($angle)))
    $right=[Drawing.PointF]::new(($baseX-$width*[Math]::Sin($angle)),($baseY+$width*[Math]::Cos($angle)))
    $poly=[Drawing.PointF[]]@([Drawing.PointF]::new($end.X,$end.Y),$left,$right)
    if($Triangle) { $graphics.FillPolygon([Drawing.Brushes]::White,$poly); $graphics.DrawPolygon($pen,$poly) }
    else { $graphics.DrawLine($pen,[Drawing.PointF]::new($end.X,$end.Y),$left); $graphics.DrawLine($pen,[Drawing.PointF]::new($end.X,$end.Y),$right) }
}
function Box([int]$X,[int]$Y,[int]$W,[int]$H,[string]$Name,[string]$Body) {
    $graphics.FillRectangle([Drawing.Brushes]::White,$X,$Y,$W,$H)
    $graphics.FillRectangle([Drawing.Brushes]::AliceBlue,$X,$Y,$W,48)
    $graphics.DrawRectangle($pen,$X,$Y,$W,$H)
    $graphics.DrawLine($pen,$X,$Y+48,$X+$W,$Y+48)
    $labelFont=$titleFont
    if($graphics.MeasureString($Name,$titleFont).Width -gt $W-24) { $labelFont=[Drawing.Font]::new('Arial',17,[Drawing.FontStyle]::Bold) }
    $graphics.DrawString($Name,$labelFont,[Drawing.Brushes]::Black,$X+12,$Y+8)
    if($labelFont -ne $titleFont) { $labelFont.Dispose() }
    $graphics.DrawString($Body,$font,[Drawing.Brushes]::Black,[Drawing.RectangleF]::new($X+12,$Y+59,$W-24,$H-63))
}
try {
    Link @(290,100,600,100) $true
    Link @(165,160,165,220,780,220,780,280) $true
    Link @(960,100,1160,100)
    Link @(600,380,440,380)
    Link @(960,380,1100,380) $true
    Link @(690,480,500,480,500,900,440,900) $true
    Link @(240,500,240,600)
    Link @(40,900,20,900,20,450,40,450) $true
    Link @(1310,600,1310,450) $true $true
    Link @(700,900,700,800,1310,800,1310,740) $false $true
    Link @(1040,900,1040,800,1310,800,1310,740) $false $true
    Link @(1380,900,1380,800,1310,800,1310,740) $false $true
    Link @(1520,380,1560,380,1560,1200,1150,1200) $true
    Box 40 40 250 120 'Main' '+ main(args)'
    Box 600 40 360 130 'MainFrame' '+ Swing controls'
    Box 1160 40 360 130 'MazePanel' '+ paintComponent()'
    Box 40 300 400 200 'Maze' "- walls, start, goal`n+ neighbors(), copy()`n+ setWall(), setStart()"
    Box 600 280 360 200 'MazeController' "- generation, worker`n- animation, busy`n- run(), invalidate()"
    Box 1100 300 420 150 '<<interface>> SearchAlgorithm' '+ search(maze, cancelled)'
    Box 40 600 400 110 '<<record>> Cell' '+ row(), col()'
    Box 40 850 400 130 'MazeFile' '+ read(), write()'
    Box 1100 600 420 140 'AbstractSearch' "# checkCancelled()`n# finish()"
    Box 550 900 300 110 'BfsSearch' '+ search()'
    Box 890 900 300 110 'DfsSearch' '+ search()'
    Box 1230 900 300 110 'AStarSearch' '+ search()'
    Box 650 1130 500 160 '<<record>> SearchResult' "+ path, expanded, elapsedNanos`n+ found(), steps()"
    $graphics.DrawString('UML: classes and key relationships',$smallFont,[Drawing.Brushes]::DimGray,40,1310)
    $bitmap.Save($OutputPath,[Drawing.Imaging.ImageFormat]::Png)
} finally {
    $graphics.Dispose(); $bitmap.Dispose(); $pen.Dispose(); $dash.Dispose()
    $titleFont.Dispose(); $font.Dispose(); $smallFont.Dispose()
}
Write-Output $OutputPath
